let product1 = "Молоко"
let price1 = 75
let count1 = 1

console.log(product1, price1 * count1)

let product2 = "Кофе"
let price2 = 420
let count2 = 1

console.log(product2, price2 * count2)

let product3 = "Яблоки"
let price3 = 160
let count3 = 1

console.log(product3, price3 * count3)

let totalSum = (price1 * count1) + (price2 * count2) + (price3 * count3)
console.log("Сумма всей покупки:", totalSum)