const currentYear = 2024;

let student = "Илья";
let year = 2006; // year должно быть числом
let age = currentYear - year; // Убраны кавычки вокруг currentYear

console.log("Студент:", student);
console.log("Год рождения:", year);
console.log("Возраст:", age);