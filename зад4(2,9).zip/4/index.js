let users = [];

users.push({ name: "Антон", age: 21 });
users.push({ name: "Василиса", age: 19 });
users.push({ name: "Никита", age: 26 });

console.log("Список пользователей:");
users.forEach((user, index) => {
    console.log(`${index + 1}. Имя: ${user.name}, Возраст: ${user.age}`);
});

let totalAge = users.reduce((sum, user) => sum + user.age, 0);
let averageAge = totalAge / users.length;

console.log(`Средний возраст пользователей: ${averageAge}`);