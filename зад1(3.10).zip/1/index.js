// Начальное состояние банкомата
let isCardInserted = true; // Карта в банкомате
let availableBalance = 500; // Доступная сумма на карте

// Функция для обработки банковской операции
function processTransaction(amount) {
    console.log(`Ввод: ${amount}`);
    if (isCardInserted && amount <= availableBalance) {
        console.log("Вывод: Операция выполняется");
    } else {
        console.log("Вывод: Операция отклонена");
    }
}

// Пример работы программы
let inputAmount = 1000; // Ввод суммы операции
processTransaction(inputAmount);