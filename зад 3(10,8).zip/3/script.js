const prices = [100, 500, 250, 750, 300];

function displayPrices(pricesArray) {
    const list = document.getElementById('price-list');
    list.innerHTML = '';

    pricesArray.forEach(price => {
        const li = document.createElement('li');
        li.textContent = ` ${price} ₽`;
        list.appendChild(li);
    });
}

function sortAscending() {
    const sortedPrices = [...prices].sort((a, b) => a - b);
    displayPrices(sortedPrices);
}

function sortDescending() {
    const sortedPrices = [...prices].sort((a, b) => b - a);
    displayPrices(sortedPrices);
}
displayPrices(prices);
document.getElementById('sort-asc').addEventListener('click', sortAscending);
document.getElementById('sort-desc').addEventListener('click', sortDescending);