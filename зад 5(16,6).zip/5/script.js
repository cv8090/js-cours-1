const timeout = 1000;
const controller = new AbortController();
const signal = controller.signal;

const timeoutId = setTimeout(() => {
    controller.abort();
}, timeout);

fetch('https://api.example.com/data', { signal })
    .then(response => {
        clearTimeout(timeoutId);
        return response.json();
    })
    .then(data => {
        console.log(data);
    })
    .catch(error => {
        if (error.name === 'AbortError') {
            console.log("Трудности с сетью");
        } else {
            console.log("Неизвестная ошибка");
        }
    });

navigator.connection.addEventListener('change', () => {
    const networkType = navigator.connection.effectiveType;
    if (navigator.onLine === false) {
        console.log("Трудности с сетью");
    } else if (networkType === 'slow-2g' || networkType === '2g') {
        console.log("Медленное соединение");
    } else if (networkType === '3g') {
        console.log("Есть проблемы с сетью");
    } else {
        console.log("");
    }
});