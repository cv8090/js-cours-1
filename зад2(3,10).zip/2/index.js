function calculateCarTax(horsepower) {
    let taxRate;

    if (horsepower <= 100) {
        taxRate = 12;
    } else if (horsepower <= 125) {
        taxRate = 25;
    } else if (horsepower <= 150) {
        taxRate = 35;
    } else if (horsepower <= 175) {
        taxRate = 45;
    } else if (horsepower <= 200) {
        taxRate = 50;
    } else if (horsepower <= 225) {
        taxRate = 65;
    } else if (horsepower <= 250) {
        taxRate = 75;
    } else {
        taxRate = 150;
    }

    const taxAmount = horsepower * taxRate;
    console.log(`Ввод: ${horsepower}\nВывод: Сумма налога: ${taxAmount}`);
}

// Example inputs
calculateCarTax(110); // Ввод: 110\nВывод: Сумма налога: 2750
calculateCarTax(540); // Ввод: 540\nВывод: Сумма налога: 81000