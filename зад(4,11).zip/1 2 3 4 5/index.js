// Задача 1

function calculateAverage(a, b, c) {
    return (a + b + c) / 3;
}

// Calling the function and logging the output in the required format
console.log(`average(1, 2, 3)`);
console.log(`Output: ${calculateAverage(1, 2, 3)}`); // Output: 2

console.log(`average(5, 10, 15)`);
console.log(`Output: ${calculateAverage(5, 10, 15)}`); // Output: 10

console.log(`average(7, 8, 9)`);
console.log(`Output: ${calculateAverage(7, 8, 9)}`); // Output: 8

// Задача 2

function celsiusToFahrenheit(celsius) {
    return celsius * 1.8 + 32;
}


function fahrenheitToCelsius(fahrenheit) {
    return (fahrenheit - 32) / 1.8;
}

// Function calls with new values and their output
console.log(`Call: celsiusToFahrenheit(30)`);
console.log(`Output: ${celsiusToFahrenheit(30)}`); // Output: 86

console.log(`Call: fahrenheitToCelsius(100)`);
console.log(`Output: ${fahrenheitToCelsius(100)}`); // Output: 37.78

// Задача 3

// Function to convert Celsius to Fahrenheit
function celsiusToFahrenheit(celsius) {
    return (celsius * 9 / 5) + 32;
}

// Function to convert Fahrenheit to Celsius
function fahrenheitToCelsius(fahrenheit) {
    return (fahrenheit - 32) * 5 / 9;
}

console.log(celsiusToFahrenheit(0)); // 32
console.log(fahrenheitToCelsius(32)); // 0

// Задача 4

let count = 15;

function countPlusOne() {
    count += 1;
    console.log(`Call: countPlusOne() \n Output: ${count}`);
}
countPlusOne(); // Output: Call: countPlusOne() \n Output: 16
countPlusOne(); // Output: Call: countPlusOne() \n Output: 17

// Задача 5
function totalSum(price, quantity, discount) {
    // Calculate the price after discount
    let priceWithDiscount = price * (1 - discount / 100);
    // Calculate the total cost
    let total = priceWithDiscount * quantity;
    return total;
}
let priceItem = 15000;
let amountItem = 4;
let discountItem = 10;
console.log(`Call: totalSum(${priceItem}, ${amountItem}, ${discountItem})`);
console.log(`Output: ${totalSum(priceItem, amountItem, discountItem)}`); //Output  54000